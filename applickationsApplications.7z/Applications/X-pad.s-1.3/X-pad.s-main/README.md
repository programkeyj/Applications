# X-pad_s
by keyj(programkeyj)
# pleas if you download this app dowload all whithout branch: 0.8;
# end after that start main.py
# ;</br>
i want from x_pad make IDE for python
