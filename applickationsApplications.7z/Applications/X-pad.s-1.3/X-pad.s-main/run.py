newfileName = "";
openfileName = "";
data = "";
input = "";