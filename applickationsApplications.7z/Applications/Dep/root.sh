# /bin/bash

if [ "$(id -u)" != "0" ]; then
   tput setaf 1; echo "Root - No"
   exit 1
else
   tput setaf 2; echo "Root - Yes"
fi