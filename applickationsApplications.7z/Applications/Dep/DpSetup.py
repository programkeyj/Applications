from colorama import Fore, init
import time
import threading
import os
import sys
import vars

sb = "#"

def Load():
	for i in range(31):
	 	time.sleep(0.2)
	 	print(Fore.YELLOW + '\r',  i*sb, str(i), '%', end='')
	 	if vars.thstop:
	 		sys.exit()
	 		break;

def CheckRoot():
	print("\r")
	os.system("./root.sh")
	

def CheckPkgs():
	
	root = os.path.exists("root.sh")
	var = os.path.exists("vars.py")
	pkgs = os.path.exists("pad/")
	if pkgs and var and root:
		print(Fore.GREEN+"\rall packages installed ", Fore.WHITE)
		return True
	else:
		print(Fore.RED+"\rmissing packages!")
		return False
	
		

def CheckDependensies():
	vars.thstop = False
	thr2.start()
	
	print(Fore.YELLOW + "[Checking dependencies]" + Fore.WHITE)
	pkgs = CheckPkgs()
	
	time.sleep(0)
	
	if pkgs == True:
		CheckRoot()
	else:
		print(Fore.RED+"// LOAD FAILED")
		vars.thstop = True
		input()
		sys.exit()
		
	time.sleep(0.5)
	print(Fore.GREEN+"\rK.J_Projs Dp seted up\n", Fore.WHITE)
	time.sleep(8)
	print(Fore.YELLOW, '\r', "#"*int(50), " 100%\n ")
	print(Fore.GREEN + "  succesfully!")
	
	os.system("python3 pad/main.py")
	sys.exit(1)
    
thr1 = threading.Thread(target = CheckDependensies, args = ())
thr2 = threading.Thread(target = Load, args=())

thr1.start()