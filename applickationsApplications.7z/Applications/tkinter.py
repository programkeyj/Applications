from tkinter import Tk, Label, Entry

root = Tk()
Label(root, text="Введiть сумму вкладу:").grid(row=0, column=0)
Entry(root ).grid(row=0, column = 2)

Label(root, text="Введiть ещё что-то:").grid(row=1, column=0)
Entry(root ).grid(row=1, column=2)

Label(root, text="Введiть ещё что-то:").grid(row=2, column=0)
Entry(root ).grid(row= 2, column=2)

root.mainloop()

