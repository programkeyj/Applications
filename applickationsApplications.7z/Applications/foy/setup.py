import DataBase
import colorama
from colorama import Fore, init, Back

print(Fore.GREEN+"добро пожаловать в переводчик\nс русского на foy-ский\n1: что-бы с русского на foy-ский\n2: что-бы с foy-ского на русский")
rev = input("вариант: ")
if rev == "1":
  while True:
    fras = input(Fore.YELLOW+"вводите на русском: "+Fore.WHITE)
    if fras in DataBase.Start:
        print(Fore.GREEN+"\n"+fras+" : на foy-ском -["+DataBase.Start[fras]+"]\n")
    else:
        print(Fore.RED+"\n[такого слова нет,\nили оно ещё не переведено]\n")
elif rev == "2":
    while True:
        fras = input(Fore.YELLOW+"вводите на foy-ском: "+Fore.WHITE)
        if fras in DataBase.End:
            print(Fore.GREEN+"\n"+fras, "на foy-ском - ["+DataBase.End[fras]+"]\n")
        else:
           print(Back.RED+"\n[такого слова нет,\nили оно ещё не переведено]\n")
else:
    print(Back.RED+"INVALID INPUT MAAAAN")